EXPIRY_FORMAT = '%Y-%m-%dT%H:%M:%SZ'

DEFAULT_API_ROOT = 'https://api.cloud.energyworx.com'

SCOPES = ['https://www.googleapis.com/auth/userinfo.email', 'openid']

